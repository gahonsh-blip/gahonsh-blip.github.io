GAHONSH FREELANCING - SAMPLE FILE BUNDLE
=========================================

These files are real, working samples used on the portfolio page. Open them, edit them,
rename them - they are yours to keep.

WHAT IS INSIDE
--------------
1. finance-dashboard-sample.xlsx   3 sheets: Dashboard, By category, Notes.
                                   Formula-driven totals (SUM, SUMIF, COUNTIF).
2. loan-calculator-sample.xlsx     Inputs on one sheet, full amortisation schedule
                                   using PMT, IPMT and PPMT.
3. inventory-tracker-sample.xlsx   Stock sheet with reorder status, conditional
                                   formatting and a movement log.
4. attendance-manager-sample.xlsx  Daily attendance grid with COUNTIF summary.
5. company-profile-sample.pdf      3-page company profile layout.
6. corporate-catalog-sample.pdf    3-page product catalogue with price tables.
7. service-brochure-sample.pdf     2-page service brochure.
8. resume-design-sample.pdf        1-page resume layout.
9. sample-document.docx            Proposal document with a pricing table.
10. sample-presentation.pptx       6-slide proposal deck.

HOW TO USE THE EXCEL FILES
--------------------------
Open in Excel, LibreOffice Calc or Google Sheets. Only the highlighted input cells are
meant to be typed into; everything else is calculated. Insert new rows inside the table
rather than below it so the formulas and filters pick them up.

NOTE
----
All names, clients and figures inside these samples are illustrative. Nothing here is
real client data.

GAHONSH Freelancing | gahonsh@gmail.com | +91 88251 83628
https://gahonsh-blip.github.io
