GAHONSH FREELANCING - PROFESSIONAL SAMPLE BUNDLE
====================================================

Real, working files. Open them, edit them, rename them - they are yours to keep.
Everything is built for a professional audience: 1,000 rows of data, live formulas,
native charts and a dashboard on every workbook.

WHAT IS INSIDE
--------------
1. finance-dashboard-sample.xlsx  1,000 transactions over 24 months.
                                  5 sheets, 5 native charts, 8 KPI cards.
                                  SUMIFS / COUNTIF / EDATE formulas throughout.
2. loan-calculator-sample.xlsx    360-month amortisation schedule plus a 1,000-row
                                  rate and term scenario engine. 3 charts.
3. inventory-tracker-sample.xlsx  1,000 SKUs, reorder logic, 300-row movement log,
                                  3 charts and 8 KPI cards.
4. attendance-manager-sample.xlsx 1,000 daily records for 40 people, three summary
                                  views, 3 charts.
5. company-profile-sample.pdf     3-page profile with KPI band and turnaround chart.
6. corporate-catalog-sample.pdf   3-page catalogue with price tables and price chart.
7. service-brochure-sample.pdf    2-page brochure with starting prices chart.
8. resume-design-sample.pdf       1-page resume layout.
9. sample-document.docx           Proposal with pricing table and an embedded chart.
10. sample-presentation.pptx      8-slide proposal deck with 2 native charts.

COLOUR SYSTEM
-------------
Neutral white and off-white base, one teal accent (#12776A) for primary data, amber
(#C9922E) for cost and secondary series, navy (#1E3A4C) for comparison, and red only
for a real problem such as overdue or critical. No decorative colour, no 3D effects.

HOW TO USE THE EXCEL FILES
--------------------------
Open in Excel, LibreOffice Calc or Google Sheets. Each data sheet is a real Excel
Table, so filters, totals and charts follow any rows you add. Only the highlighted
input cells on the loan Calculator sheet are meant to be typed into.

NOTE
----
All names, clients and figures are illustrative. Nothing here is real client data.

GAHONSH Freelancing | gahonsh@gmail.com | +91 88251 83628
https://gahonsh-blip.github.io
